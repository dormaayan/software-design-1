package library;

import il.ac.technion.cs.sd.book.ext.LineStorage;
import il.ac.technion.cs.sd.book.ext.LineStorageFactory;

public class TestStorerFactory implements LineStorageFactory {
  
  @Override public LineStorage open(String arg0) {
    return new TestStorer();
  }
  
}
